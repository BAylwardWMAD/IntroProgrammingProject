﻿namespace BurgerJoint
{
    partial class frmBurgerShack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstCart = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpOrder = new System.Windows.Forms.GroupBox();
            this.grpCombos = new System.Windows.Forms.GroupBox();
            this.btnCombo3 = new System.Windows.Forms.Button();
            this.btnCombo2 = new System.Windows.Forms.Button();
            this.btnCombo1 = new System.Windows.Forms.Button();
            this.grpDrink = new System.Windows.Forms.GroupBox();
            this.rdoCoffee = new System.Windows.Forms.RadioButton();
            this.rdoWater = new System.Windows.Forms.RadioButton();
            this.rdoPepsi = new System.Windows.Forms.RadioButton();
            this.grpSides = new System.Windows.Forms.GroupBox();
            this.rdoSalad = new System.Windows.Forms.RadioButton();
            this.rdoPoutine = new System.Windows.Forms.RadioButton();
            this.rdoFries = new System.Windows.Forms.RadioButton();
            this.grpBurgers = new System.Windows.Forms.GroupBox();
            this.rdoBaconCheese = new System.Windows.Forms.RadioButton();
            this.rdoCheeseburger = new System.Windows.Forms.RadioButton();
            this.rdoHamburger = new System.Windows.Forms.RadioButton();
            this.btnAddToCart = new System.Windows.Forms.Button();
            this.grpPayment = new System.Windows.Forms.GroupBox();
            this.cboYear = new System.Windows.Forms.ComboBox();
            this.cboMonth = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.chkDiscount = new System.Windows.Forms.CheckBox();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCVC = new System.Windows.Forms.TextBox();
            this.txtCCNum = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnValidate = new System.Windows.Forms.Button();
            this.grpOrder.SuspendLayout();
            this.grpCombos.SuspendLayout();
            this.grpDrink.SuspendLayout();
            this.grpSides.SuspendLayout();
            this.grpBurgers.SuspendLayout();
            this.grpPayment.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstCart
            // 
            this.lstCart.FormattingEnabled = true;
            this.lstCart.Location = new System.Drawing.Point(669, 35);
            this.lstCart.Name = "lstCart";
            this.lstCart.Size = new System.Drawing.Size(270, 173);
            this.lstCart.TabIndex = 0;
            this.lstCart.DoubleClick += new System.EventHandler(this.lstCart_DoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(389, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Burger Shack";
            // 
            // grpOrder
            // 
            this.grpOrder.Controls.Add(this.lblTotal);
            this.grpOrder.Controls.Add(this.grpCombos);
            this.grpOrder.Controls.Add(this.grpDrink);
            this.grpOrder.Controls.Add(this.grpSides);
            this.grpOrder.Controls.Add(this.grpBurgers);
            this.grpOrder.Controls.Add(this.btnAddToCart);
            this.grpOrder.Controls.Add(this.lstCart);
            this.grpOrder.Location = new System.Drawing.Point(23, 80);
            this.grpOrder.Name = "grpOrder";
            this.grpOrder.Size = new System.Drawing.Size(945, 308);
            this.grpOrder.TabIndex = 2;
            this.grpOrder.TabStop = false;
            this.grpOrder.Text = "Order Information";
            // 
            // grpCombos
            // 
            this.grpCombos.Controls.Add(this.btnCombo3);
            this.grpCombos.Controls.Add(this.btnCombo2);
            this.grpCombos.Controls.Add(this.btnCombo1);
            this.grpCombos.Location = new System.Drawing.Point(27, 198);
            this.grpCombos.Name = "grpCombos";
            this.grpCombos.Size = new System.Drawing.Size(612, 100);
            this.grpCombos.TabIndex = 18;
            this.grpCombos.TabStop = false;
            this.grpCombos.Text = "Combos";
            // 
            // btnCombo3
            // 
            this.btnCombo3.Location = new System.Drawing.Point(386, 29);
            this.btnCombo3.Name = "btnCombo3";
            this.btnCombo3.Size = new System.Drawing.Size(144, 38);
            this.btnCombo3.TabIndex = 18;
            this.btnCombo3.Text = "Combo #3";
            this.btnCombo3.UseVisualStyleBackColor = true;
            this.btnCombo3.Click += new System.EventHandler(this.btnCombo3_Click);
            // 
            // btnCombo2
            // 
            this.btnCombo2.Location = new System.Drawing.Point(206, 29);
            this.btnCombo2.Name = "btnCombo2";
            this.btnCombo2.Size = new System.Drawing.Size(144, 38);
            this.btnCombo2.TabIndex = 17;
            this.btnCombo2.Text = "Combo #2";
            this.btnCombo2.UseVisualStyleBackColor = true;
            this.btnCombo2.Click += new System.EventHandler(this.btnCombo2_Click);
            // 
            // btnCombo1
            // 
            this.btnCombo1.AccessibleDescription = "";
            this.btnCombo1.Location = new System.Drawing.Point(26, 29);
            this.btnCombo1.Name = "btnCombo1";
            this.btnCombo1.Size = new System.Drawing.Size(144, 38);
            this.btnCombo1.TabIndex = 16;
            this.btnCombo1.Text = "Combo #1";
            this.btnCombo1.UseVisualStyleBackColor = true;
            this.btnCombo1.Click += new System.EventHandler(this.btnCombo1_Click);
            // 
            // grpDrink
            // 
            this.grpDrink.Controls.Add(this.rdoCoffee);
            this.grpDrink.Controls.Add(this.rdoWater);
            this.grpDrink.Controls.Add(this.rdoPepsi);
            this.grpDrink.Location = new System.Drawing.Point(439, 35);
            this.grpDrink.Name = "grpDrink";
            this.grpDrink.Size = new System.Drawing.Size(200, 157);
            this.grpDrink.TabIndex = 17;
            this.grpDrink.TabStop = false;
            this.grpDrink.Text = "Drinks";
            // 
            // rdoCoffee
            // 
            this.rdoCoffee.AutoSize = true;
            this.rdoCoffee.Location = new System.Drawing.Point(33, 101);
            this.rdoCoffee.Name = "rdoCoffee";
            this.rdoCoffee.Size = new System.Drawing.Size(56, 17);
            this.rdoCoffee.TabIndex = 29;
            this.rdoCoffee.TabStop = true;
            this.rdoCoffee.Text = "Coffee";
            this.rdoCoffee.UseVisualStyleBackColor = true;
            // 
            // rdoWater
            // 
            this.rdoWater.AutoSize = true;
            this.rdoWater.Location = new System.Drawing.Point(33, 69);
            this.rdoWater.Name = "rdoWater";
            this.rdoWater.Size = new System.Drawing.Size(54, 17);
            this.rdoWater.TabIndex = 28;
            this.rdoWater.TabStop = true;
            this.rdoWater.Text = "Water";
            this.rdoWater.UseVisualStyleBackColor = true;
            // 
            // rdoPepsi
            // 
            this.rdoPepsi.AutoSize = true;
            this.rdoPepsi.Location = new System.Drawing.Point(33, 36);
            this.rdoPepsi.Name = "rdoPepsi";
            this.rdoPepsi.Size = new System.Drawing.Size(51, 17);
            this.rdoPepsi.TabIndex = 27;
            this.rdoPepsi.TabStop = true;
            this.rdoPepsi.Text = "Pepsi";
            this.rdoPepsi.UseVisualStyleBackColor = true;
            // 
            // grpSides
            // 
            this.grpSides.Controls.Add(this.rdoSalad);
            this.grpSides.Controls.Add(this.rdoPoutine);
            this.grpSides.Controls.Add(this.rdoFries);
            this.grpSides.Location = new System.Drawing.Point(233, 35);
            this.grpSides.Name = "grpSides";
            this.grpSides.Size = new System.Drawing.Size(200, 157);
            this.grpSides.TabIndex = 17;
            this.grpSides.TabStop = false;
            this.grpSides.Text = "Sides";
            // 
            // rdoSalad
            // 
            this.rdoSalad.AutoSize = true;
            this.rdoSalad.Location = new System.Drawing.Point(32, 101);
            this.rdoSalad.Name = "rdoSalad";
            this.rdoSalad.Size = new System.Drawing.Size(52, 17);
            this.rdoSalad.TabIndex = 26;
            this.rdoSalad.TabStop = true;
            this.rdoSalad.Text = "Salad";
            this.rdoSalad.UseVisualStyleBackColor = true;
            // 
            // rdoPoutine
            // 
            this.rdoPoutine.AutoSize = true;
            this.rdoPoutine.Location = new System.Drawing.Point(32, 69);
            this.rdoPoutine.Name = "rdoPoutine";
            this.rdoPoutine.Size = new System.Drawing.Size(61, 17);
            this.rdoPoutine.TabIndex = 25;
            this.rdoPoutine.TabStop = true;
            this.rdoPoutine.Text = "Poutine";
            this.rdoPoutine.UseVisualStyleBackColor = true;
            // 
            // rdoFries
            // 
            this.rdoFries.AutoSize = true;
            this.rdoFries.Location = new System.Drawing.Point(32, 36);
            this.rdoFries.Name = "rdoFries";
            this.rdoFries.Size = new System.Drawing.Size(47, 17);
            this.rdoFries.TabIndex = 24;
            this.rdoFries.TabStop = true;
            this.rdoFries.Text = "Fries";
            this.rdoFries.UseVisualStyleBackColor = true;
            // 
            // grpBurgers
            // 
            this.grpBurgers.Controls.Add(this.rdoBaconCheese);
            this.grpBurgers.Controls.Add(this.rdoCheeseburger);
            this.grpBurgers.Controls.Add(this.rdoHamburger);
            this.grpBurgers.Location = new System.Drawing.Point(27, 35);
            this.grpBurgers.Name = "grpBurgers";
            this.grpBurgers.Size = new System.Drawing.Size(200, 157);
            this.grpBurgers.TabIndex = 16;
            this.grpBurgers.TabStop = false;
            this.grpBurgers.Text = "Burgers";
            // 
            // rdoBaconCheese
            // 
            this.rdoBaconCheese.AutoSize = true;
            this.rdoBaconCheese.Location = new System.Drawing.Point(23, 101);
            this.rdoBaconCheese.Name = "rdoBaconCheese";
            this.rdoBaconCheese.Size = new System.Drawing.Size(125, 17);
            this.rdoBaconCheese.TabIndex = 23;
            this.rdoBaconCheese.TabStop = true;
            this.rdoBaconCheese.Text = "Bacon Cheeseburger";
            this.rdoBaconCheese.UseVisualStyleBackColor = true;
            // 
            // rdoCheeseburger
            // 
            this.rdoCheeseburger.AutoSize = true;
            this.rdoCheeseburger.Location = new System.Drawing.Point(23, 69);
            this.rdoCheeseburger.Name = "rdoCheeseburger";
            this.rdoCheeseburger.Size = new System.Drawing.Size(91, 17);
            this.rdoCheeseburger.TabIndex = 22;
            this.rdoCheeseburger.TabStop = true;
            this.rdoCheeseburger.Text = "Cheeseburger";
            this.rdoCheeseburger.UseVisualStyleBackColor = true;
            // 
            // rdoHamburger
            // 
            this.rdoHamburger.AutoSize = true;
            this.rdoHamburger.Location = new System.Drawing.Point(23, 36);
            this.rdoHamburger.Name = "rdoHamburger";
            this.rdoHamburger.Size = new System.Drawing.Size(77, 17);
            this.rdoHamburger.TabIndex = 21;
            this.rdoHamburger.TabStop = true;
            this.rdoHamburger.Text = "Hamburger";
            this.rdoHamburger.UseVisualStyleBackColor = true;
            // 
            // btnAddToCart
            // 
            this.btnAddToCart.Location = new System.Drawing.Point(801, 260);
            this.btnAddToCart.Name = "btnAddToCart";
            this.btnAddToCart.Size = new System.Drawing.Size(144, 38);
            this.btnAddToCart.TabIndex = 15;
            this.btnAddToCart.Text = "Add to Cart";
            this.btnAddToCart.UseVisualStyleBackColor = true;
            this.btnAddToCart.Click += new System.EventHandler(this.btnAddToCart_Click);
            // 
            // grpPayment
            // 
            this.grpPayment.Controls.Add(this.btnValidate);
            this.grpPayment.Controls.Add(this.cboYear);
            this.grpPayment.Controls.Add(this.cboMonth);
            this.grpPayment.Controls.Add(this.label10);
            this.grpPayment.Controls.Add(this.chkDiscount);
            this.grpPayment.Controls.Add(this.lblDisplay);
            this.grpPayment.Controls.Add(this.txtEmail);
            this.grpPayment.Controls.Add(this.label9);
            this.grpPayment.Controls.Add(this.txtCVC);
            this.grpPayment.Controls.Add(this.txtCCNum);
            this.grpPayment.Controls.Add(this.txtName);
            this.grpPayment.Controls.Add(this.label8);
            this.grpPayment.Controls.Add(this.label7);
            this.grpPayment.Controls.Add(this.label6);
            this.grpPayment.Controls.Add(this.label5);
            this.grpPayment.Controls.Add(this.label4);
            this.grpPayment.Controls.Add(this.label3);
            this.grpPayment.Controls.Add(this.label2);
            this.grpPayment.Location = new System.Drawing.Point(23, 394);
            this.grpPayment.Name = "grpPayment";
            this.grpPayment.Size = new System.Drawing.Size(945, 224);
            this.grpPayment.TabIndex = 3;
            this.grpPayment.TabStop = false;
            this.grpPayment.Text = "Payment Information";
            // 
            // cboYear
            // 
            this.cboYear.FormattingEnabled = true;
            this.cboYear.Location = new System.Drawing.Point(218, 122);
            this.cboYear.Name = "cboYear";
            this.cboYear.Size = new System.Drawing.Size(68, 21);
            this.cboYear.TabIndex = 22;
            // 
            // cboMonth
            // 
            this.cboMonth.FormattingEnabled = true;
            this.cboMonth.Location = new System.Drawing.Point(96, 122);
            this.cboMonth.Name = "cboMonth";
            this.cboMonth.Size = new System.Drawing.Size(68, 21);
            this.cboMonth.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(349, 125);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(242, 39);
            this.label10.TabIndex = 20;
            this.label10.Text = "If you sign-up for our newsletter, we will apply a 10% discount to your order.";
            // 
            // chkDiscount
            // 
            this.chkDiscount.AutoSize = true;
            this.chkDiscount.Location = new System.Drawing.Point(352, 99);
            this.chkDiscount.Name = "chkDiscount";
            this.chkDiscount.Size = new System.Drawing.Size(182, 17);
            this.chkDiscount.TabIndex = 19;
            this.chkDiscount.Text = "Click to sign-up for our newsletter";
            this.chkDiscount.UseVisualStyleBackColor = true;
            // 
            // lblDisplay
            // 
            this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDisplay.Location = new System.Drawing.Point(632, 28);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(294, 138);
            this.lblDisplay.TabIndex = 17;
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(352, 70);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(249, 20);
            this.txtEmail.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(349, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(242, 39);
            this.label9.TabIndex = 12;
            this.label9.Text = "To Sign-Up for our rewards program, please enter a valid email address:";
            // 
            // txtCVC
            // 
            this.txtCVC.Location = new System.Drawing.Point(43, 150);
            this.txtCVC.Name = "txtCVC";
            this.txtCVC.Size = new System.Drawing.Size(39, 20);
            this.txtCVC.TabIndex = 11;
            // 
            // txtCCNum
            // 
            this.txtCCNum.Location = new System.Drawing.Point(84, 96);
            this.txtCCNum.Name = "txtCCNum";
            this.txtCCNum.Size = new System.Drawing.Size(238, 20);
            this.txtCCNum.TabIndex = 8;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(50, 70);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(201, 20);
            this.txtName.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "CVC:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(180, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Month:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Expiry:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Credit Card #:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Please enter your credit card information:";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(824, 645);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(144, 38);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(674, 645);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(144, 38);
            this.btnReset.TabIndex = 15;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Location = new System.Drawing.Point(524, 645);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(144, 38);
            this.btnPlaceOrder.TabIndex = 14;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotal.Location = new System.Drawing.Point(651, 260);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(144, 38);
            this.lblTotal.TabIndex = 19;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnValidate
            // 
            this.btnValidate.Location = new System.Drawing.Point(127, 162);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(144, 38);
            this.btnValidate.TabIndex = 23;
            this.btnValidate.Text = "Validate CC#";
            this.btnValidate.UseVisualStyleBackColor = true;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // frmBurgerShack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 695);
            this.Controls.Add(this.grpPayment);
            this.Controls.Add(this.grpOrder);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnPlaceOrder);
            this.Name = "frmBurgerShack";
            this.Text = "Burger Shack";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmBurgerShack_FormClosing);
            this.Load += new System.EventHandler(this.frmBurgerShack_Load);
            this.grpOrder.ResumeLayout(false);
            this.grpCombos.ResumeLayout(false);
            this.grpDrink.ResumeLayout(false);
            this.grpDrink.PerformLayout();
            this.grpSides.ResumeLayout(false);
            this.grpSides.PerformLayout();
            this.grpBurgers.ResumeLayout(false);
            this.grpBurgers.PerformLayout();
            this.grpPayment.ResumeLayout(false);
            this.grpPayment.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstCart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpOrder;
        private System.Windows.Forms.GroupBox grpPayment;
        private System.Windows.Forms.TextBox txtCVC;
        private System.Windows.Forms.TextBox txtCCNum;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpCombos;
        private System.Windows.Forms.Button btnCombo3;
        private System.Windows.Forms.Button btnCombo2;
        private System.Windows.Forms.Button btnCombo1;
        private System.Windows.Forms.GroupBox grpDrink;
        private System.Windows.Forms.RadioButton rdoCoffee;
        private System.Windows.Forms.RadioButton rdoWater;
        private System.Windows.Forms.RadioButton rdoPepsi;
        private System.Windows.Forms.GroupBox grpSides;
        private System.Windows.Forms.RadioButton rdoSalad;
        private System.Windows.Forms.RadioButton rdoPoutine;
        private System.Windows.Forms.RadioButton rdoFries;
        private System.Windows.Forms.GroupBox grpBurgers;
        private System.Windows.Forms.RadioButton rdoBaconCheese;
        private System.Windows.Forms.RadioButton rdoCheeseburger;
        private System.Windows.Forms.RadioButton rdoHamburger;
        private System.Windows.Forms.Button btnAddToCart;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkDiscount;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboYear;
        private System.Windows.Forms.ComboBox cboMonth;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnValidate;
    }
}

