﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerJoint
{
    public partial class frmBurgerShack : Form
    {
        private const decimal DISCOUNT = .10m;
        private static decimal total;
        private const decimal TAX = .15m;

        public frmBurgerShack()
        {
            InitializeComponent();
        }

        //Burger Price = $3.00
        //Cheeseburger Price = $4.00
        //Bacon Cheeseburger Price = $5.50
        //Fries Price = $2.00
        //Poutine Price = $4.00
        //Salad Price = $2.50
        //Pepsi Price = $2.00
        //Water Price = $1.50
        //Coffee Price = $1.00

        //Combo#1: Hamburger w/Fries & Pepsi = $6.00
        //Combo#2: Cheeseburger w/Fries & Pepsi = $7.00
        //Combo#3: Bacon Cheeseburger w/Poutine & Pepsi = $10.00

        #region Methods
        private void Setup()
        {
            btnValidate.Enabled = true;
            btnValidate.BackColor = default;
            rdoHamburger.Checked = true;
            rdoFries.Checked = true;
            rdoPepsi.Checked = true;
            chkDiscount.Checked = false;

            lstCart.Items.Clear();

            grpPayment.Enabled = false;

            btnPlaceOrder.Enabled = false;

            txtName.Text = string.Empty;
            txtCCNum.Text = string.Empty;
            txtCVC.Text = string.Empty;
            txtEmail.Text = string.Empty;

            lblDisplay.Text = string.Empty;
            lblTotal.Text = string.Empty;

            cboMonth.SelectedIndex = -1;
            cboYear.SelectedIndex = -1;
            cboMonth.Items.Clear();
            cboYear.Items.Clear();

            for(int month = 1; month <= 12; month++)
            {
                cboMonth.Items.Add(month.ToString());
            }
            for (int year = 2020; year <= 2025; year++)
            {
                cboYear.Items.Add(year.ToString());
            }
                      

            total = 0;
            

        }

        private bool IsValidCCNum(string name, string CCNum, string CVC)
        {
            return name.Length > 3 && name.Contains(" ") && long.TryParse(CCNum, out _) && CCNum.Length == 16 &&
                CCNum.StartsWith("45") && int.TryParse(CVC, out int CVCNum) && CVC.Length == 3 && CVCNum > 0 && cboMonth.SelectedIndex != -1
                && cboYear.SelectedIndex != -1;
        }

        private bool IsValidEmail (string email)
        {
            return email.Length > 5 && email.Contains("@") && email.IndexOf("@") > 3 && email.Contains(".") && email.IndexOf(".", email.IndexOf("@")) > 2 &&
                email.EndsWith(".com") || email.EndsWith(".ca"); 
        }
        #endregion

        #region Load/Reset

        private void frmBurgerShack_Load(object sender, EventArgs e)
        {
            Setup();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Setup();
        }
        #endregion

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                decimal currentTotal = 0.00m;
                string currentOrder;

                //Determining Burger cost

                if (rdoHamburger.Checked)
                {
                    currentTotal = 3.00m;
                    currentOrder = "Hamburger - ";
                }
                else if (rdoCheeseburger.Checked)
                {
                    currentTotal = 4.00m;
                    currentOrder = "Cheeseburger - ";
                }
                else
                {
                    currentTotal = 5.50m;
                    currentOrder = "Bacon Cheeseburger - ";
                }

                //Determining Side order cost

                if (rdoFries.Checked)
                {
                    currentTotal += 2.00m;
                    currentOrder += "Fries - ";
                }
                else if (rdoPoutine.Checked)
                {
                    currentTotal += 4.00m;
                    currentOrder += "Poutine - ";
                }
                else
                {
                    currentTotal += 2.50m;
                    currentOrder += "Salad - ";
                }

                //Determining Drink cost

                if (rdoPepsi.Checked)
                {
                    currentTotal += 2.00m;
                    currentOrder += "Pepsi";
                }
                else if (rdoWater.Checked)
                {
                    currentTotal += 1.50m;
                    currentOrder += "Water";
                }
                else
                {
                    currentTotal += 1.00m;
                    currentOrder += "Coffee";
                }

                //Getting total of entire order added to Cart

                total += currentTotal;
                lstCart.Items.Add(currentOrder + " = " + currentTotal.ToString("c"));


                grpPayment.Enabled = true;

                lblTotal.Text = $"Your total is: {total:c}";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lstCart_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (lstCart.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select an item to remove from your cart.", "Invalid Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }  
                
                
                total -= Convert.ToDecimal(lstCart.SelectedItem.ToString().Substring(lstCart.SelectedItem.ToString().IndexOf("$") + 1));
                
                lstCart.Items.Remove(lstCart.SelectedItem);
                lblTotal.Text = $"Your total is: {total:c}";

                if (lstCart.Items.Count == 0)
                {
                    grpPayment.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnCombo1_Click(object sender, EventArgs e)
        {
            lstCart.Items.Add("Hamburger w/Fries & Pepsi = $6.00");
            total += 6.00m;
            lblTotal.Text = $"Your total is: {total:c}";
            grpPayment.Enabled = true;
        }

        private void btnCombo2_Click(object sender, EventArgs e)
        {
            lstCart.Items.Add("Cheeseburger w/Fries & Pepsi = $7.00");
            total += 7.00m;
            lblTotal.Text = $"Your total is: {total:c}";
            grpPayment.Enabled = true;
        }

        private void btnCombo3_Click(object sender, EventArgs e)
        {
            lstCart.Items.Add("Bacon Cheeseburger w/Poutine & Pepsi = $10.00");
            total += 10.00m;
            lblTotal.Text = $"Your total is: {total:c}";
            grpPayment.Enabled = true;
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (!IsValidEmail(txtEmail.Text.Trim()) || chkDiscount.Checked == false)
                {
                    if(MessageBox.Show("You have not entered a valid email or signed up for our newsletter are you sure you wish to continue??", 
                        "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        return;
                    }
                    else
                    {
                        lblDisplay.Text = $"Your subtotal is {total:c}\r\nYour tax is {total * TAX:c}\r\n" +
                        $"Your credit card has been charged with {total + (total * TAX):c}";
                        btnPlaceOrder.Enabled = false;
                    }
                    
                }
                else
                {
                    lblDisplay.Text = $"Your subtotal is {total:c}\r\nYour tax is {total * TAX:c}\r\n" +
                        $"Your discount today is {((total + (total * TAX)) * DISCOUNT):c}\r\n" +
                        $"Your credit card has been charged with {total + (total * TAX) - ((total +(total * TAX)) * DISCOUNT):c}";
                    btnPlaceOrder.Enabled = false;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            if (!IsValidCCNum(txtName.Text.Trim(), txtCCNum.Text.Trim(), txtCVC.Text.Trim()))
            {
                MessageBox.Show("Please ensure your credit card information is Valid.", "Invalid Credit Card",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnPlaceOrder.Enabled = true;
            btnValidate.BackColor = Color.Green;
            btnValidate.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmBurgerShack_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Are you sure you wish to exit?", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
